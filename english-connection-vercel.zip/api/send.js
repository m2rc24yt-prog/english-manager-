import { timingSafeEqual } from 'node:crypto';
export default async function handler(req,res){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='POST')return res.status(405).json({error:'Método no permitido'});
 const {ADMIN_SEND_KEY,WHATSAPP_TOKEN,WHATSAPP_PHONE_NUMBER_ID,WHATSAPP_API_VERSION}=process.env;
 if(!ADMIN_SEND_KEY||!WHATSAPP_TOKEN||!WHATSAPP_PHONE_NUMBER_ID||!WHATSAPP_API_VERSION)return res.status(503).json({error:'API pendiente de configurar'});
 const a=Buffer.from(req.headers.authorization||''),b=Buffer.from('Bearer '+ADMIN_SEND_KEY);
 if(a.length!==b.length||!timingSafeEqual(a,b))return res.status(401).json({error:'Clave incorrecta'});
 const {to,template,language}=req.body||{};
 if(!/^\d{8,15}$/.test(to)||!/^\w{1,512}$/.test(template)||!/^\w{2,12}$/.test(language))return res.status(400).json({error:'Datos inválidos'});
 try{const r=await fetch(`https://graph.facebook.com/${WHATSAPP_API_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`,{method:'POST',headers:{Authorization:`Bearer ${WHATSAPP_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to,type:'template',template:{name:template,language:{code:language}}})});const d=await r.json();return res.status(r.ok?200:400).json(r.ok?{id:d.messages?.[0]?.id}:{error:'Meta rechazó la solicitud ('+(d.error?.code||r.status)+')'});}catch{return res.status(502).json({error:'No se pudo contactar con Meta'});}
}
