# English Connection – L’Hospitalet · Collblanc Pubilles
Prototipo actualizado sobre Academia Manager. React + Vite, función serverless para WhatsApp Cloud API.

## Vercel
Subir el contenido de esta carpeta a GitHub (package.json en la raíz), importar en Vercel. Framework Vite, build `npm run build`, salida `dist`, instalación `npm install`. Para uso comercial contratar un plan adecuado. No introducir datos reales en este prototipo.

## WhatsApp
En Settings > Environment Variables añadir ADMIN_SEND_KEY (clave larga aleatoria), WHATSAPP_TOKEN (token de Meta), WHATSAPP_PHONE_NUMBER_ID (ID del número, no el teléfono), WHATSAPP_API_VERSION (versión Graph activa indicada por Meta, incluyendo v). Volver a desplegar. Crear y aprobar una plantilla sin variables en WhatsApp Manager; usar su nombre e idioma exactos en el formulario. La clave de envío protege el endpoint, no toda la web. El token nunca se incluye en el cliente. Probar primero con el número de prueba autorizado por Meta. Los borradores locales no se envían como texto libre. El historial indica aceptación de la API, no entrega efectiva.

## Local
`npm install`, `npm run dev` para interfaz; para probar la función usar Vercel CLI (`npx vercel dev`) y variables locales. No subir secretos a GitHub.

## Límites
Contactos, consentimiento, grupos, plantillas e historial guardados en localStorage del navegador; no se sincronizan. El control de consentimiento es local, no una garantía del servidor. Pendientes: autenticación completa, base de datos segura, webhooks verificados, recepción de conversaciones, estados de entrega, plantillas con variables, gestión central de bajas, límites de envío y auditoría. No listo para producción con datos de alumnos. No se ha probado con credenciales reales.
