import React, { useMemo, useState, useEffect } from 'react';
import { MessageCircle, LayoutDashboard, FileText, Users, Settings, Search, Plus, Send, Phone, Pencil, Trash2, GraduationCap, CheckCircle2, Menu, X } from 'lucide-react';

const initialTemplates = [
  { id: 1, title: 'Recordatorio de pago', category: 'Administración', message: 'Hola, te recordamos que está pendiente el pago de la mensualidad de la academia. Si ya lo has realizado, puedes ignorar este mensaje. ¡Muchas gracias!' },
  { id: 2, title: 'Aviso de festivo', category: 'Avisos', message: 'Hola, te informamos de que la academia permanecerá cerrada el próximo día indicado por festivo. ¡Gracias por vuestra comprensión!' },
  { id: 3, title: 'Cambio de horario', category: 'Clases', message: 'Hola, te informamos de que ha habido un cambio en el horario de las clases. Por favor, contacta con la academia si necesitas más información.' },
  { id: 4, title: 'Falta de asistencia', category: 'Alumnos', message: 'Hola, hoy hemos registrado una ausencia en la clase. Queríamos confirmar que todo está bien. ¡Un saludo!' }
];

function useStored(key, initial) {
 const [value,setValue]=useState(()=>{try{return JSON.parse(localStorage.getItem(key)) ?? initial}catch{return initial}});
 useEffect(()=>{localStorage.setItem(key,JSON.stringify(value))},[key,value]); return [value,setValue];
}
function App() {
 const [contacts,setContacts]=useStored('ec.contacts',[]);
 const [history,setHistory]=useStored('ec.history',[]);
 const [password,setPassword]=useState('');
 const [official,setOfficial]=useState('');
 const [language,setLanguage]=useState('es');
 const [busy,setBusy]=useState(false);
 const [name,setName]=useState(''); const [phone,setPhone]=useState(''); const [group,setGroup]=useState(''); const [consent,setConsent]=useState(false);

  const [page, setPage] = useState('Panel general');
  const [templates, setTemplates] = useStored('ec.templates',initialTemplates);
  const [selected, setSelected] = useState(1);
  const [numbers, setNumbers] = useState('');
  const [message, setMessage] = useState(initialTemplates[0].message);
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState(false);
  const [draftTitle, setDraftTitle] = useState('');
  const [draftCategory, setDraftCategory] = useState('Administración');
  const [draftMessage, setDraftMessage] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);

  const active = templates.find(t => t.id === selected);
  const filtered = useMemo(() => templates.filter(t => (t.title + ' ' + t.category).toLowerCase().includes(search.toLowerCase())), [templates, search]);
  const parsedNumbers = numbers.split(/[\n,;]+/).map(n => n.trim().replace(/[^\d+]/g, '')).filter(Boolean);
  const validNumbers = parsedNumbers.map(n => n.startsWith('+') ? n.slice(1) : n).filter(n => /^\d{8,15}$/.test(n));

  function chooseTemplate(t) { setSelected(t.id); setMessage(t.message); setNotice(''); }
  async function sendWhatsApp() {
    const targets=[...new Set(validNumbers)];
    if (!targets.length || !official.trim() || !password) {setNotice('Añade números, nombre de plantilla aprobada y clave de envío.');return;}
    if(targets.some(n=>!contacts.some(c=>c.phone===n && c.consent))){setNotice('Todos los destinatarios deben tener consentimiento registrado y no estar dados de baja.');return;}
    if(!confirm(`¿Enviar la plantilla oficial ${official} a ${targets.length} contactos?`))return;
    setBusy(true);
    try {for(const to of targets){let status='Error de conexión';let id='';try{const r=await fetch('/api/send',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+password},body:JSON.stringify({to,template:official.trim(),language})});const d=await r.json();status=r.ok?'Aceptado por Meta':(d.error||'Error');id=d.id||'';}catch{} setHistory(h=>[{to,status,id,date:new Date().toISOString(),template:official},...h]);}setNotice('Proceso terminado. Consulta el historial para ver el resultado de cada solicitud.');}finally{setBusy(false);}
  }
  function openNew() { setDraftTitle(''); setDraftCategory('Administración'); setDraftMessage(''); setEditing(true); }
  function saveTemplate(e) {
    e.preventDefault();
    if (!draftTitle.trim() || !draftMessage.trim()) return;
    const item = { id: Date.now(), title: draftTitle.trim(), category: draftCategory, message: draftMessage.trim() };
    setTemplates(prev => [item, ...prev]); chooseTemplate(item); setEditing(false);
  }
  function deleteTemplate(id) {
    setTemplates(prev => prev.filter(t => t.id !== id));
    if (selected === id) { const next = templates.find(t => t.id !== id); if (next) chooseTemplate(next); }
  }

  const nav = [
    { label: 'Mensajes', icon: MessageCircle },
    { label: 'Alumnos', icon: Users },
    { label: 'Panel general', icon: LayoutDashboard },
    { label: 'Historial', icon: FileText }, { label: 'Grupos', icon: Users }, { label: 'Configuración', icon: Settings }
  ];

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'show' : ''}`}>
      <div className="brand"><div><img className="brand-logo" src="/logo.jpeg" alt="English Connection"/><span>L’Hospitalet · Collblanc Pubilles</span></div><button className="close-menu" onClick={() => setMobileMenu(false)}><X/></button></div>
      <div className="workspace-label">ESPACIO DE TRABAJO</div>
      <nav>{nav.map(item => <button key={item.label} className={`nav-item ${page === item.label ? 'active' : ''}`} onClick={() => {setPage(item.label); setMobileMenu(false);}}><item.icon size={18}/>{item.label}{item.label === 'Mensajes' && <span className="nav-count">{templates.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><MessageCircle size={17}/></div><b>¿Necesitas ayuda?</b><p>Organiza tus comunicaciones desde un solo lugar.</p></div><div className="profile"><div className="avatar">AD</div><div><b>Administrador</b><span>Cuenta de academia</span></div><Settings size={17} className="profile-settings"/></div></div>
    </aside>
    {mobileMenu && <div className="scrim" onClick={() => setMobileMenu(false)} />}
    <main className="main">
      <header className="topbar"><button className="menu-toggle" onClick={() => setMobileMenu(true)}><Menu/></button><div className="breadcrumb">English Connection <span>/</span> <b>{page}</b></div><div className="top-right"><span className="status-dot"></span><span>Espacio de trabajo</span><div className="avatar small">AD</div></div></header>
      {page === 'Mensajes' ? <div className="content">
        <div className="page-heading"><div><div className="eyebrow">COMUNICACIÓN</div><h1>Centro de mensajes</h1><p>Prepara y envía comunicaciones a alumnos y familias.</p></div><button className="primary-btn" onClick={openNew}><Plus size={17}/> Nueva plantilla</button></div>
        <div className="stats-row"><div className="stat-card"><div className="stat-icon purple"><FileText size={19}/></div><div><span>Plantillas guardadas</span><strong>{templates.length}</strong></div></div><div className="stat-card"><div className="stat-icon green"><MessageCircle size={19}/></div><div><span>Canal de envío</span><strong className="stat-word">WhatsApp</strong></div></div><div className="stat-card"><div className="stat-icon orange"><Users size={19}/></div><div><span>Destinatarios</span><strong>{validNumbers.length}</strong></div></div></div>
        <div className="work-grid">
          <section className="panel templates-panel"><div className="panel-heading"><div><h2>Plantillas</h2><p>Selecciona un mensaje para utilizarlo.</p></div><span className="count-pill">{templates.length}</span></div><div className="search-wrap"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar plantilla..."/></div><div className="template-list">{filtered.map(t => <button key={t.id} className={`template-item ${selected === t.id ? 'chosen' : ''}`} onClick={() => chooseTemplate(t)}><div className="template-top"><span className="template-category">{t.category}</span><span className="template-arrow">↗</span></div><b>{t.title}</b><p>{t.message}</p></button>)}{filtered.length === 0 && <div className="empty">No se han encontrado plantillas.</div>}</div></section>
          <section className="panel composer-panel"><div className="panel-heading"><div><h2>Preparar envío</h2><p>Edita el texto antes de enviarlo.</p></div><span className="whatsapp-label"><MessageCircle size={15}/> WhatsApp</span></div>
            <label className="field-label">MENSAJE</label><textarea className="message-box" value={message} onChange={e => setMessage(e.target.value)} placeholder="Escribe el mensaje que quieres enviar..."/><div className="editor-foot"><span>El texto se puede modificar antes de enviarlo.</span><span>{message.length} caracteres</span></div>
            <div className="section-divider"></div><div className="recipient-heading"><div><label className="field-label">DESTINATARIOS</label><p>Añade los números de teléfono con prefijo internacional.</p></div><span className="recipient-counter">{validNumbers.length} válidos</span></div>
            <textarea className="numbers-box" value={numbers} onChange={e => setNumbers(e.target.value)} placeholder={'34600111222\n34600333444\n34600555666'}/><div className="field-hint"><Phone size={13}/> Un número por línea o separados por comas. Ejemplo: 34 para España.</div>
            {notice && <div className={`notice ${notice.startsWith('Añade') ? 'warning' : 'success'}`}>{notice.startsWith('Añade') ? <Phone size={16}/> : <CheckCircle2 size={16}/>}<span>{notice}</span></div>}
            <label className="field-label">PLANTILLA APROBADA EN META (SIN VARIABLES)</label><input className="form-input" value={official} onChange={e=>setOfficial(e.target.value)} placeholder="nombre_de_plantilla"/><input className="form-input" value={language} onChange={e=>setLanguage(e.target.value)} placeholder="Idioma: es"/><input className="form-input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Clave de envío"/><button className="send-btn" onClick={sendWhatsApp} disabled={busy}><Send size={17}/>{busy?'Enviando…':'Enviar mediante API oficial'}</button><p className="privacy-note">Se envía el contenido aprobado en Meta, no el borrador editable de arriba.</p>
          </section>
        </div>
      </div> : <div className="content"><div className="page-heading"><div><div className="eyebrow">ENGLISH CONNECTION</div><h1>{page}</h1><p>L’Hospitalet · Collblanc Pubilles</p></div></div>
      {page==='Panel general' && <><div className="hero"><h1>Bienvenido a English Connection</h1><p>Tu centro de comunicaciones con alumnos y familias.</p></div><div className="stats-row">{[['Contactos',contacts.length],['Plantillas',templates.length],['Solicitudes',history.length]].map(([k,v])=><div className="stat-card" key={k}><div><span>{k}</span><strong>{v}</strong></div></div>)}</div><button className="primary-btn" onClick={()=>setPage('Mensajes')}>Preparar comunicación</button></>}
      {page==='Alumnos' && <section className="panel placeholder"><form onSubmit={e=>{e.preventDefault();const n=phone.replace(/\D/g,'');if(!/^\d{8,15}$/.test(n)||contacts.some(c=>c.phone===n))return;setContacts([...contacts,{name,phone:n,group,consent}]);setName('');setPhone('');setConsent(false)}}><input className="form-input" required placeholder="Nombre" value={name} onChange={e=>setName(e.target.value)}/><input className="form-input" required placeholder="Teléfono internacional" value={phone} onChange={e=>setPhone(e.target.value)}/><input className="form-input" placeholder="Grupo" value={group} onChange={e=>setGroup(e.target.value)}/><label><input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)}/> Consentimiento para WhatsApp</label><br/><button className="primary-btn">Añadir contacto</button></form>{contacts.map(c=><div className="record" key={c.phone}><b>{c.name}</b><p>{c.phone} · {c.group}</p><label><input type="checkbox" checked={c.consent} onChange={e=>setContacts(contacts.map(x=>x.phone===c.phone?{...x,consent:e.target.checked}:x))}/> Consentimiento activo</label><button className="primary-btn" onClick={()=>{setNumbers(c.phone);setPage('Mensajes')}}>Seleccionar</button></div>)}</section>}
      {page==='Grupos' && <section className="panel placeholder">{[...new Set(contacts.map(c=>c.group).filter(Boolean))].map(g=><div className="record" key={g}><b>{g}</b><p>{contacts.filter(c=>c.group===g).length} contactos</p><button className="primary-btn" onClick={()=>{setNumbers(contacts.filter(c=>c.group===g&&c.consent).map(c=>c.phone).join('\n'));setPage('Mensajes')}}>Seleccionar grupo</button></div>)}<p>Crea grupos al añadir contactos.</p></section>}
      {page==='Historial' && <section className="panel placeholder">{history.length===0&&<p>No hay solicitudes todavía.</p>}{history.map((h,i)=><div className="record" key={i}><b>{h.to} · {h.status}</b><p>{h.template} · {new Date(h.date).toLocaleString('es-ES')}</p></div>)}</section>}
      {page==='Configuración' && <section className="panel placeholder"><h2>WhatsApp Business Cloud API</h2><p>Configura las variables de entorno en Vercel según el README. Los datos de esta versión se guardan únicamente en este navegador. No uses datos reales hasta disponer de autenticación y almacenamiento seguro.</p></section>}
      </div>}

    </main>
    {editing && <div className="modal-backdrop"><form className="modal" onSubmit={saveTemplate}><div className="modal-head"><div><h2>Nueva plantilla</h2><p>Crea un mensaje reutilizable.</p></div><button type="button" className="icon-btn" onClick={() => setEditing(false)}><X/></button></div><label className="field-label">NOMBRE</label><input className="form-input" value={draftTitle} onChange={e => setDraftTitle(e.target.value)} placeholder="Ej. Recordatorio de matrícula" required/><label className="field-label">CATEGORÍA</label><select className="form-input" value={draftCategory} onChange={e => setDraftCategory(e.target.value)}><option>Administración</option><option>Avisos</option><option>Clases</option><option>Alumnos</option></select><label className="field-label">TEXTO DEL MENSAJE</label><textarea className="form-textarea" value={draftMessage} onChange={e => setDraftMessage(e.target.value)} placeholder="Escribe el mensaje..." required/><button className="primary-btn modal-submit" type="submit"><Plus size={17}/> Guardar plantilla</button></form></div>}
  </div>;
}

export default App;